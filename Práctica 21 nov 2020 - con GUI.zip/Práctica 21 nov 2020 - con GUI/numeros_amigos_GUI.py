from tkinter import *

window = Tk() #Creamos el objeto

window.title("Numeros amigos")

window.geometry('900x100')

label_1 = Label(window, text="\n\nCódigo para determinar si dos numeros son amigos, es decir, si la suma de los divisores propios de un numero es igual al otro y viceversa.")

label_1.grid(column=0, row=0)

label_2 = Label(window, text="Inserte numero: ")

label_2.grid(column=0, row=0)
	
txt = Entry(window,width=10)

txt.grid(column=1, row=0)

def numeros_amigos():
	
	y = txt.get()
	
	n = int(y)

	m,c = 0, 0
	
	for i in range(1,n-1,1):
		if (n%i) == 0:
			m += i
	
	for i in range(1,m-1,1):
		if (m%i) == 0:
			c += i


	if c == n:
		result = str(n) + " y " + str(m) + " son numeros amigos"
		label_2.configure(text=result)
		button.configure(text="Salir", command=exit)
		
	else:
		label_2.configure(text="Inserte de nuevo, ya que el número insertado no tiene número amigo")
		button.configure(text="Entendido", command=numeros_amigos)


button = Button(window, text="Entendido", bg="orange", fg="red", command=numeros_amigos)

button.grid(column=2, row=0)

window.mainloop()






